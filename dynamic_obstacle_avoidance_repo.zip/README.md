# Video-Based Dynamic Obstacle Avoidance Using Deep Reinforcement Learning

This repository contains code and experiments for a video-based obstacle avoidance system using deep reinforcement learning.