# Training loop for Double DQN obstacle avoidance
