Summary of experiments and results.
